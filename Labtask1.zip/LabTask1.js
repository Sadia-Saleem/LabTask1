//LabTask1
//sadia saleem
//Fa19-BCS-013
//Question 1
let array1=[2,3,6,1,7];
let z=0;
  let y =parseInt(array1[1]);
  for(let i=0; i<y; i++)
  {
   z=array1[1];
  }
  console.log((y+1), " digit from last is ="+ z);
//Question 2
/*var value = 23617,
    sum = value.toString().split('').map(Number).reduce(function (x, y) {
            return x + y;
        }, 0);
console.log(sum);*/
//Question 3
/*let numberString = [2,3,6,1,7];


  let s = 0;
  for (let i = 0; i < numberString.length; i++) {
    if (numberString[i] % 2 === 0){ 
        s = s + numberString[i];
    }
  }
 
 console.log(s);*/
 //Question 4
/* for(let i=0;i<=10;i++)
{
    console.log("cube is "+(i*i*i));
    console.log("square is "+(i*i)); 
}*/
 //Question 5(a)
 /*function vowelPosition(str)
{
    var x=str.split(",")
    console.log(x[0])
}
vowelPosition("a,e,i,o,u")
//5(b)
function reverseNumber(a)
{
	a = a + "";
	return a.split("").reverse().join("");
}
console.log(Number(reverseNumber(123456)));*/
//Question 6
/*const randomInteger  = Math.ceil(Math.random() * 10);
 let guessNumber=6;
 if (guessNumber == randomInteger)
   console.log("MYou WIN");
  else
   console.log("Not matched");*/
//Question 7
/*function checkAppearance(integerArray)
{
    var endPosition = integerArray.length - 1;
    if(integerArray.length>=2){
    return integerArray[0] == 10 || integerArray[endPosition] == 10;
    }
}
console.log(checkAppearance([1, 2 , 10]));
console.log(checkAppearance([1, 10, 2]));
console.log(checkAppearance([10, 1, 2]));*/
//Question 8
/*function orderOfAlphabet(str)
  {
return str.split('').sort().join('');
  }
console.log(orderOfAlphabet("comsats"));*/